public class Questions {
    
    private String foo;
    String borderAndSpace = "============================================================\n";
    
    public Questions (String bar){
        foo = bar;
    }
    
    public void questionOne()
    {
        System.out.println(borderAndSpace);
        
        System.out.println("Gender? (Male/Female)");
        System.out.println();
        
        System.out.println(borderAndSpace);
    }
    
    public void questionTwo()
    {
        System.out.println();
            
        System.out.println(borderAndSpace);
        
        System.out.println("Race? (Caucaoid/Negroid/Mongoloid)");
        System.out.println();
        
        System.out.println(borderAndSpace);
    }
    
    public void questionThree()
    {
        System.out.println();
            
        System.out.println(borderAndSpace);
        
        System.out.println("Bone? (Femur/Tibia/Fibula/Humerus/Ulna/Radius)");
        System.out.println();
        
        System.out.println(borderAndSpace);
    }
    
    public void questionFour()
    {
        System.out.println();
            
        System.out.println(borderAndSpace);
        
        System.out.println("Length of bone? (cm)");
        System.out.println();
        
        System.out.println(borderAndSpace);
    }
}