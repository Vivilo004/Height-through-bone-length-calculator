import java.util.Scanner;

public class BoneLengthCalc
{
    public static void main(String[] args)
    {
        String borderAndSpace = "============================================================\n";
        String end = "};" + "\n" + "\n" + "------------------------------------------------------------" + "\n" + "\n" + "Highlight the array then right click to copy." + "\n" + "\n";
        boolean stop = false;
        
        while (stop == false) {
            Scanner input = new Scanner(System.in);
            
            System.out.println(borderAndSpace);
            
            System.out.println("Welcome to my height calculator! Press ENTER to continue!");
            System.out.println();
            
            System.out.println(borderAndSpace);
            
            String enter = input.nextLine();
            
            
            Questions qOne = new Questions(enter);
            //Prints gender question
            qOne.questionOne();
            
            String gender = input.nextLine();
            
            
            Questions qTwo = new Questions(gender);
            //prints race question
            qTwo.questionTwo();
            
            String race = input.nextLine();
            
            
            Questions qThree = new Questions(race);
            //prints bone question
            qThree.questionThree();
            
            String bone = input.nextLine();
            
            
            Questions qFour = new Questions(bone);
            //prints length question
            qFour.questionFour();
            
            String convert = input.nextLine();
            System.out.println();
            
            System.out.println(borderAndSpace);
            
            if(gender.equalsIgnoreCase("Male")) {
                double length = Integer.parseInt(convert);
                
                if(race.equalsIgnoreCase("Caucaoid")) {
                    
                    if(bone.equalsIgnoreCase("Femur")) {
                        double midRange = 2.32 * length + 65.53;
                        double highRange = midRange + 3.94;
                        double lowRange = midRange - 3.94;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Tibia")) {
                        double midRange = 2.42 * length + 81.93;
                        double highRange = midRange + 4.0;
                        double lowRange = midRange - 4.0;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Fibula")) {
                        double midRange = 2.6 * length + 75.5;
                        double highRange = midRange + 3.86;
                        double lowRange = midRange - 3.86;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Humerus")) {
                        double midRange = 2.89 * length + 78.1;
                        double highRange = midRange + 4.57;
                        double lowRange = midRange - 4.57;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Ulna")) {
                        double midRange = 3.76 * length + 75.55;
                        double highRange = midRange + 4.72;
                        double lowRange = midRange - 4.72;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Radius")) {
                        double midRange = 3.79 * length + 79.42;
                        double highRange = midRange + 4.66;
                        double lowRange = midRange - 4.66;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    }  
                    
                    
                } else if (race.equalsIgnoreCase("Negroid")) {
                    
                    if(bone.equalsIgnoreCase("Femur")) {
                        double midRange = 2.10 * length + 72.22;
                        double highRange = midRange + 3.91;
                        double lowRange = midRange - 3.91;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Tibia")) {
                        double midRange = 2.19 * length + 85.36;
                        double highRange = midRange + 3.96;
                        double lowRange = midRange - 3.96;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Fibula")) {
                        double midRange = 2.34 * length + 80.53;
                        double highRange = midRange + 4.02;
                        double lowRange = midRange - 4.02;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Humerus")) {
                        double midRange = 2.88 * length + 75.48;
                        double highRange = midRange + 4.23;
                        double lowRange = midRange - 4.23;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Ulna")) {
                        double midRange = 3.2 * length + 82.77;
                        double highRange = midRange + 4.74;
                        double lowRange = midRange - 4.74;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Radius")) {
                        double midRange = 3.32 * length + 85.43;
                        double highRange = midRange + 4.57;
                        double lowRange = midRange - 4.57;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    }
                    
                } else if (race.equalsIgnoreCase("Mongoloid")) {
                    
                    if(bone.equalsIgnoreCase("Femur")) {
                        double midRange = 2.15 * length + 72.57;
                        double highRange = midRange + 3.8;
                        double lowRange = midRange - 3.8;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Tibia")) {
                        double midRange = 2.39 * length + 81.45;
                        double highRange = midRange + 3.24;
                        double lowRange = midRange - 3.24;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Fibula")) {
                        double midRange = 2.4 * length + 80.56;
                        double highRange = midRange + 3.24;
                        double lowRange = midRange - 3.24;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Humerus")) {
                        double midRange = 2.68 * length + 83.29;
                        double highRange = midRange + 4.16;
                        double lowRange = midRange - 4.16;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Ulna")) {
                        double midRange = 3.48 * length + 77.45;
                        double highRange = midRange + 4.66;
                        double lowRange = midRange - 4.66;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Radius")) {
                        double midRange = 3.54 * length + 82.0;
                        double highRange = midRange + 4.6;
                        double lowRange = midRange - 4.6;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    }
                    
                }
//_________________________________________________________________________________________________________________________________________________ 
            } else if (gender.equalsIgnoreCase("Female")) {
                double length = Integer.parseInt(convert);
                
                if(race.equalsIgnoreCase("Caucaoid")) {
                    
                    if(bone.equalsIgnoreCase("Femur")) {
                        double midRange = 2.47 * length + 54.10;
                        double highRange = midRange + 3.72;
                        double lowRange = midRange - 3.72;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Tibia")) {
                        double midRange = 2.90 * length + 61.53;
                        double highRange = midRange + 3.66;
                        double lowRange = midRange - 3.66;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Fibula")) {
                        double midRange = 2.93 * length + 59.61;
                        double highRange = midRange + 3.57;
                        double lowRange = midRange - 3.57;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Humerus")) {
                        double midRange = 3.36 * length + 57.97;
                        double highRange = midRange + 4.45;
                        double lowRange = midRange - 4.45;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Ulna")) {
                        double midRange = 4.27 * length + 57.76;
                        double highRange = midRange + 4.3;
                        double lowRange = midRange - 4.3;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Radius")) {
                        double midRange = 4.74 * length + 54.93;
                        double highRange = midRange + 4.24;
                        double lowRange = midRange - 4.24;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    }  
                    
                    
                } else if (race.equalsIgnoreCase("Negroid")) {
                    
                    if(bone.equalsIgnoreCase("Femur")) {
                        double midRange = 2.28 * length + 59.76;
                        double highRange = midRange + 3.41;
                        double lowRange = midRange - 3.41;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Tibia")) {
                        double midRange = 2.45 * length + 72.56;
                        double highRange = midRange + 3.7;
                        double lowRange = midRange - 3.7;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Fibula")) {
                        double midRange = 2.49 * length + 70.90;
                        double highRange = midRange + 3.8;
                        double lowRange = midRange - 3.8;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Humerus")) {
                        double midRange = 3.08 * length + 64.67;
                        double highRange = midRange + 4.25;
                        double lowRange = midRange - 4.25;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Ulna")) {
                        double midRange = 3.31 * length + 75.38;
                        double highRange = midRange + 4.83;
                        double lowRange = midRange - 4.83;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Radius")) {
                        double midRange = 3.67 * length + 71.79;
                        double highRange = midRange + 4.59;
                        double lowRange = midRange - 4.59;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    }
                    
                } else if (race.equalsIgnoreCase("Mongoloid")) {
                    
                    if(bone.equalsIgnoreCase("Femur")) {
                        double midRange = 2.15 * length + 72.57;
                        double highRange = midRange + 3.8;
                        double lowRange = midRange - 3.8;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Tibia")) {
                        double midRange = 2.39 * length + 81.45;
                        double highRange = midRange + 3.24;
                        double lowRange = midRange - 3.24;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Fibula")) {
                        double midRange = 2.4 * length + 80.56;
                        double highRange = midRange + 3.24;
                        double lowRange = midRange - 3.24;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Humerus")) {
                        double midRange = 2.68 * length + 83.19;
                        double highRange = midRange + 4.16;
                        double lowRange = midRange - 4.16;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Ulna")) {
                        double midRange = 3.48 * length + 77.45;
                        double highRange = midRange + 4.66;
                        double lowRange = midRange - 4.66;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    } else if (bone.equalsIgnoreCase("Radius")) {
                        double midRange = 3.54 * length + 82.00;
                        double highRange = midRange + 4.6;
                        double lowRange = midRange - 4.6;
                        
                        double highRangeInches = highRange / 2.54;
                        double lowRangeInches = lowRange / 2.54;
                        
                        double highRangeFeet = highRangeInches / 12;
                        double lowRangeFeet = lowRangeInches / 12;
                        
                        System.out.println("Estimated Height in inches: " + highRangeInches + " to " + lowRangeInches);
                        System.out.println("Estimated Height in feet: " + highRangeFeet + " to " + lowRangeFeet);
                        System.out.println();
                        
                    }
                    
                }
            }
        } 
    }
}